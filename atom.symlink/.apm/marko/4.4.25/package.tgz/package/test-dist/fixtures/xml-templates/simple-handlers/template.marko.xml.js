function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      __renderer = __helpers.r,
      bn_ = __renderer(require("../../taglib/simple-hello-tag")),
      __tag = __helpers.t;

  return function render(data, out) {
    var dynamic = data.dynamic;

    out.w('<ul><li>');
    __tag(out, bn_, {
      "name": "world"
    });

    out.w('</li><li>');
    __tag(out, bn_, {
      "name": dynamic,
      "adult": true
    });

    out.w('</li><li>');
    __tag(out, bn_, {
      "name": "Dynamic: " + dynamic,
      "adult": false
    });

    out.w('</li></ul>');
  };
}
(module.exports = require("marko").c(__filename)).c(create);