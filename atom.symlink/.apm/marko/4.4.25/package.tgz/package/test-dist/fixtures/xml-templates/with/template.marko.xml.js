function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      escapeXml = __helpers.x,
      forEach = __helpers.f;

  return function render(data, out) {
    (function () {
      var x = 1,
          y = 7,
          z = x + 10,
          a;

      out.w(escapeXml(x) + ' ' + escapeXml(y) + ' ' + escapeXml(z));
    })();

    forEach([1, 2, 3], function (i) {
      (function () {
        var message = i + ') hello';

        out.w('<div>' + escapeXml(message) + '</div>');
      })();
    });
  };
}
(module.exports = require("marko").c(__filename)).c(create);