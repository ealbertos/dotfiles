function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      escapeXml = __helpers.x;

  return function render(data, out) {
    var person = data.person;

    out.w('Hello ' + escapeXml(person.name) + '. You are from ' + escapeXml(person.address.city) + ', ' + escapeXml(person.address.state));
  };
}
(module.exports = require("marko").c(__filename)).c(create);