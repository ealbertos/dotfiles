function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      forEach = __helpers.f,
      escapeXml = __helpers.x;

  return function render(data, out) {
    var colors = ['red', 'green', 'blue'];

    forEach(colors, function (color) {
      out.w('<div>' + escapeXml(color) + '</div>');
    });

    colors = ['orange', 'purple', 'yellow'];

    forEach(colors, function (color) {
      out.w('<div>' + escapeXml(color) + '</div>');
    });
  };
}
(module.exports = require("marko").c(__filename)).c(create);