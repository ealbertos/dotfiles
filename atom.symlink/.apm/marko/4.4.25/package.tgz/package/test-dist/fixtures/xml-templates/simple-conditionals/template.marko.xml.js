function create(__helpers) {
    var str = __helpers.s,
        empty = __helpers.e,
        notEmpty = __helpers.ne,
        attr = __helpers.a,
        escapeXml = __helpers.x;

    return function render(data, out) {
        var name = data.name,
            count = data.count;

        out.w('<div' + attr("class", count > 50 ? "over-50" : '') + '></div><div' + attr("class", count < 50 ? "under-50" : '') + '></div><div' + attr("class", count < 50 ? "under-50" : "over-50") + '></div><div' + attr("class", count < 50 ? "under-50" : "#") + '></div><span' + attr("class", count ? "under;-50\\" : "over-50") + '></span><input type="checked"' + attr("checked", true ? true : '') + '>' + escapeXml(count > 50 ? (name ? "Hello " + name + "! " : '') + "Over 50" : (name ? "Hello " + name + "! " : '') + "50 or less"));
    };
}
(module.exports = require("marko").c(__filename)).c(create);