function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      escapeXml = __helpers.x,
      escapeXmlAttr = __helpers.xa,
      attr = __helpers.a;

  return function render(data, out) {
    var name = data.name,
        welcome = data.welcome;

    out.w(str(welcome) + str(welcome) + welcome + ' ' + escapeXml(name) + '<div title="' + escapeXmlAttr(welcome) + ' &lt;hello&gt;"' + attr("data-name", name) + '></div><div data-attr="Hello ' + escapeXmlAttr(name) + ' &lt;hello&gt;"' + attr("data-nested-attr", out.captureString(function () {
      out.w('&lt;Hello&gt; ' + escapeXmlAttr(name) + ' &lt;hello&gt;');
    }), false) + ' data-nested-attr2="Hello &lt;John&gt; &lt;hello&gt;">Hello &lt;John>\u00a9 &lt;hello> <START></div>');
  };
}
(module.exports = require("marko").c(__filename)).c(create);