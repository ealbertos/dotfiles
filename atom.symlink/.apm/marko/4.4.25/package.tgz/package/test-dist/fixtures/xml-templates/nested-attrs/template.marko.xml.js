function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      __renderer = __helpers.r,
      bj_ = __renderer(require("../../taglib/popover-tag")),
      __tag = __helpers.t,
      attr = __helpers.a,
      forEach = __helpers.f,
      escapeXmlAttr = __helpers.xa;

  return function render(data, out) {
    var active = data.active;

    __tag(out, bj_, {
      "title": out.captureString(function () {
        out.w('Popover Title');
      }),
      "content": out.captureString(function () {
        out.w('Popover Content');
      })
    }, function (out) {
      out.w('Link Text');
    });

    out.w('<div' + attr("class", active ? "tab-active" : '') + attr("align", out.captureString(function () {
      out.w('center');
    }), false) + '></div><div' + attr("title", out.captureString(function () {
      forEach(['red', 'green', 'blue'], function (color) {
        out.w(' ' + escapeXmlAttr(color) + '! ');
      });
    }), false) + '></div>');
  };
}
(module.exports = require("marko").c(__filename)).c(create);