function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      escapeXml = __helpers.x;

  return function render(data, out) {
    var name = data.name;

    out.w('<html><head><title>Optimizer: Server Includes</title></head><body>Hello ' + escapeXml(name) + '! <script>\n            $(function() {\n                alert(\'test\');    \n            })\n            </script></body></html>');
  };
}
(module.exports = require("marko").c(__filename)).c(create);