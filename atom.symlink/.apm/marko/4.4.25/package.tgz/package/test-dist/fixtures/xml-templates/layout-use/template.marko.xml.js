function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      __loadTemplate = __helpers.l,
      __layout_default_marko_xml = __loadTemplate(require.resolve("./layout-default.marko.xml"), require),
      __renderer = __helpers.r,
      bh_ = __renderer(require("marko-layout/use-tag")),
      __tag = __helpers.t,
      bi_ = __renderer(require("marko-layout/put-tag"));

  return function render(data, out) {
    __tag(out, bh_, {
      "template": __layout_default_marko_xml,
      "getContent": function (__layoutHelper) {
        __tag(out, bi_, {
          "into": "body",
          "layout": __layoutHelper
        }, function (out) {
          out.w('BODY CONTENT');
        });
        __tag(out, bi_, {
          "into": "footer",
          "layout": __layoutHelper
        }, function (out) {
          out.w('FOOTER CONTENT');
        });
      },
      "*": {
        "showHeader": false
      }
    });
    __tag(out, bh_, {
      "template": __layout_default_marko_xml,
      "getContent": function (__layoutHelper) {
        __tag(out, bi_, {
          "into": "header",
          "layout": __layoutHelper
        }, function (out) {
          out.w('HEADER CONTENT');
        });
        __tag(out, bi_, {
          "into": "body",
          "layout": __layoutHelper
        }, function (out) {
          out.w('BODY CONTENT');
        });
        __tag(out, bi_, {
          "into": "footer",
          "layout": __layoutHelper
        }, function (out) {
          out.w('FOOTER CONTENT');
        });
      },
      "*": {
        "showHeader": true
      }
    });
    __tag(out, bh_, {
      "template": __layout_default_marko_xml,
      "getContent": function (__layoutHelper) {
        __tag(out, bi_, {
          "into": "header",
          "value": "VALUE HEADER",
          "layout": __layoutHelper
        });
        __tag(out, bi_, {
          "into": "body",
          "layout": __layoutHelper
        }, function (out) {
          out.w('BODY CONTENT');
        });
        __tag(out, bi_, {
          "into": "footer",
          "layout": __layoutHelper
        }, function (out) {
          out.w('FOOTER CONTENT');
        });
      },
      "*": {
        "showHeader": true
      }
    });
    __tag(out, bh_, {
      "template": __loadTemplate(require.resolve('./layout-default.marko.xml'), require),
      "getContent": function (__layoutHelper) {
        __tag(out, bi_, {
          "into": "body",
          "layout": __layoutHelper
        }, function (out) {
          out.w('BODY CONTENT');
        });
        __tag(out, bi_, {
          "into": "footer",
          "layout": __layoutHelper
        }, function (out) {
          out.w('FOOTER CONTENT');
        });
      },
      "*": {
        "showHeader": true
      }
    });
  };
}
(module.exports = require("marko").c(__filename)).c(create);