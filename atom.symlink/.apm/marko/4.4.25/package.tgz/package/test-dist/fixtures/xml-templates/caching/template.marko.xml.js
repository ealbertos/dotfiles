function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      __renderer = __helpers.r,
      bb_ = __renderer(require("../../../../taglibs/caching/cached-fragment-tag")),
      __tag = __helpers.t,
      escapeXml = __helpers.x;

  return function render(data, out) {
    var count = 0;

    function foo(cacheName, cacheKey) {
      return __helpers.c(out, function () {
        __tag(out, bb_, {
          "cacheKey": cacheKey,
          "cacheName": cacheName
        }, function (out) {
          out.w('Count: ' + escapeXml(count++));
        });
      });
    }

    out.w(foo('cacheA', 'keyA') + foo('cacheA', 'keyA') + foo('cacheA', 'keyB') + foo('cacheB', 'keyA') + foo('cacheB', 'keyA') + foo('cacheB', 'keyB'));
  };
}
(module.exports = require("marko").c(__filename)).c(create);