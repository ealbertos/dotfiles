function create(__helpers) {
    var str = __helpers.s,
        empty = __helpers.e,
        notEmpty = __helpers.ne;

    return function render(data, out) {
        if (true) {
            out.w(' HELLO ');
        }if (false) {
            out.w(' WORLD ');
        }
    };
}
(module.exports = require("marko").c(__filename)).c(create);