function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      forEach = __helpers.f,
      escapeXml = __helpers.x,
      forEachWithStatusVar = __helpers.fv;

  return function render(data, out) {
    forEach(['a', 'b', 'c'], function (item) {
      out.w(escapeXml(item));
    });

    forEachWithStatusVar(['a', 'b', 'c'], function (item, loop) {
      out.w(escapeXml(item) + ' - ' + escapeXml(loop.isFirst()) + ' - ' + escapeXml(loop.isLast()) + ' - ' + escapeXml(loop.getIndex()) + ' - ' + escapeXml(loop.getLength()));

      if (!loop.isLast()) {
        out.w(", ");
      }
    });

    forEachWithStatusVar(['red', 'green', 'blue'], function (item, loop) {
      out.w('<div>' + escapeXml(item) + ' - ' + escapeXml(loop.isFirst()) + ' - ' + escapeXml(loop.isLast()) + ' - ' + escapeXml(loop.getIndex()) + ' - ' + escapeXml(loop.getLength()) + '</div>');

      if (!loop.isLast()) {
        out.w(', ');
      }
    });
  };
}
(module.exports = require("marko").c(__filename)).c(create);