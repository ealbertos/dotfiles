function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      attrs = __helpers.as;

  return function render(data, out) {
    var myAttrs = data.myAttrs;

    out.w('<div data-encoding="&quot;hello&quot;"' + attrs(myAttrs) + '>Hello World!</div>');
  };
}
(module.exports = require("marko").c(__filename)).c(create);