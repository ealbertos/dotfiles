function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      __renderer = __helpers.r,
      bk_ = __renderer(require("../../taglib/tabs-tag")),
      __tag = __helpers.t,
      bl_ = __renderer(require("../../taglib/tab-tag"));

  return function render(data, out) {
    var showConditionalTab = data.showConditionalTab;

    __tag(out, bk_, {}, function (out, tabs) {
      __tag(out, bl_, {
        "title": "Tab 1",
        "tabs": tabs
      }, function (out) {
        out.w('Tab 1 content');
      });
      __tag(out, bl_, {
        "title": "Tab 2",
        "tabs": tabs
      }, function (out) {
        out.w('Tab 2 content');
      });

      if (showConditionalTab) {
        __tag(out, bl_, {
          "title": "Tab 3",
          "tabs": tabs
        }, function (out) {
          out.w('Tab 3 content');
        });
      }
    });
  };
}
(module.exports = require("marko").c(__filename)).c(create);