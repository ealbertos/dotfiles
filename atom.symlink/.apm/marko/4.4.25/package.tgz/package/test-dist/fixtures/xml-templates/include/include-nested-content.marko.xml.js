function create(__helpers) {
    var str = __helpers.s,
        empty = __helpers.e,
        notEmpty = __helpers.ne,
        escapeXml = __helpers.x;

    return function render(data, out) {
        var name = data.name,
            count = data.count,
            invokeBody = data.invokeBody;

        out.w('<div class="nested"><h1>Hello ' + escapeXml(name) + '! You have ' + escapeXml(count) + ' new messages.</h1><p>' + escapeXml(invokeBody()) + '</p></div>');
    };
}
(module.exports = require("marko").c(__filename)).c(create);