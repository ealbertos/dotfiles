function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne;

  return function render(data, out) {
    if (true) {
      out.w('A');
    } else {
      out.w('B');
    }

    out.w(' , ');

    if (false) {
      out.w('A');
    } else {
      out.w('B');
    }

    out.w(' , ');

    if (false) {
      out.w('A');
    } else if (false) {
      out.w('B');
    } else {
      out.w('C');
    }

    out.w(' , ');

    if (false) {
      out.w('<div>A</div>');
    } else if (false) {
      out.w('<div>B</div>');
    } else {
      out.w('<div>C</div>');
    }
  };
}
(module.exports = require("marko").c(__filename)).c(create);