function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      escapeXml = __helpers.x;

  return function render(data, out) {
    out.w(escapeXml("BEGIN  this whitespace   should be retained   END") + ' test ' + escapeXml("hello") + ' Long paragraph of text should retain spacing between lines. <ul><li>One</li><li>Two</li></ul><a href="Test">Hello World!</a><pre>\n   begin      end     \n</pre><div>\n   begin      end     \n</div><div>\n   begin      end     \n</div>');

    if (true) {
      out.w('begin end');
    }
  };
}
(module.exports = require("marko").c(__filename)).c(create);