function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne;

  return function render(data, out) {
    out.w('<img src="test.jpg"><div class="self-closing-not-allowed"></div><script src="test.js"></script><br>');
  };
}
(module.exports = require("marko").c(__filename)).c(create);