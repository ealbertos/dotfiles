function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      __loadTemplate = __helpers.l,
      __include_target_marko_xml = __loadTemplate(require.resolve("./include-target.marko.xml"), require),
      __include_nested_content_marko_xml = __loadTemplate(require.resolve("./include-nested-content.marko.xml"), require);

  return function render(data, out) {
    __helpers.i(out, __include_target_marko_xml, { "name": 'Frank', "count": "20" });
    __helpers.i(out, __include_target_marko_xml, { "name": "Frank", "count": 20 });
    __helpers.i(out, __include_target_marko_xml, { name: 'Frank', count: 20 });
    __helpers.i(out, __include_nested_content_marko_xml, { "name": "Frank", "count": 20, "body": __helpers.c(out, function () {
        out.w('Have a <b>wonderful</b> day!');
      }) });
  };
}
(module.exports = require("marko").c(__filename)).c(create);