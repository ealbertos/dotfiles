function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      testHelpers = require("./test-helpers"),
      escapeXml = __helpers.x;

  return function render(data, out) {
    out.w('Hello ' + escapeXml(testHelpers.upperCase("world")) + '! Hello ' + escapeXml(testHelpers.trim("   World   ")) + '!');
  };
}
(module.exports = require("marko").c(__filename)).c(create);