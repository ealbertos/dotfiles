function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      __renderer = __helpers.r,
      bf_ = __renderer(require("../../taglib/dynamic-attributes-tag3")),
      __tag = __helpers.t;

  return function render(data, out) {
    __tag(out, bf_, {
      "test": "World",
      "class": "my-class",
      "id": "myId"
    });
  };
}
(module.exports = require("marko").c(__filename)).c(create);