function create(__helpers) {
    var str = __helpers.s,
        empty = __helpers.e,
        notEmpty = __helpers.ne,
        escapeXml = __helpers.x;

    return function render(data, out) {
        var name = data.name,
            count = data.count;

        out.w(escapeXml(name != null ? "Hello " + name.toUpperCase() + "! You have " + count + " new messages." : null));
    };
}
(module.exports = require("marko").c(__filename)).c(create);