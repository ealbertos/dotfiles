function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      escapeXml = __helpers.x;

  return function render(data, out) {

    function test(name) {
      out.write("Hello " + name + "!");
    }

    function test2(name) {
      return "Hello " + name + "!";
    }
    out.w(' A <p>');

    test('World');

    out.w(escapeXml(test2('World')) + '</p> B <p>');

    function greeting(name, count) {
      return __helpers.c(out, function () {
        out.w('Hello ' + escapeXml(name) + '! You have ' + escapeXml(count) + ' new messages.');
      });
    }

    out.w(greeting("Frank", 10) + greeting('John', 20) + '</p>');
  };
}
(module.exports = require("marko").c(__filename)).c(create);