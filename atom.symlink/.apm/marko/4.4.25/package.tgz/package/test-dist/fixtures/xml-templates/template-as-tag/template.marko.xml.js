function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      bo_ = __helpers.l(require.resolve("../../taglib/page-title-tag"));

  return function render(data, out) {
    out.w('<div>');

    bo_.render({ "title": "My Page Title" }, out);

    out.w('</div>');
  };
}
(module.exports = require("marko").c(__filename)).c(create);