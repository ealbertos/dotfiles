function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      escapeXml = __helpers.x;

  return function render(data, out) {
    out.w('VV {1} XX \\{1} YY ${1} ZZ \\' + escapeXml(1));
  };
}
(module.exports = require("marko").c(__filename)).c(create);