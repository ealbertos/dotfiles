function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      forEachProp = __helpers.fp,
      escapeXml = __helpers.x;

  return function render(data, out) {
    forEachProp({ 'foo': 'low', 'bar': 'high' }, function (name, value) {
      out.w('[' + escapeXml(name) + '=' + escapeXml(value) + ']');
    });

    out.w('<ul>');

    forEachProp({ 'foo': 'low', 'bar': 'high' }, function (name, value) {
      out.w('<li>[' + escapeXml(name) + '=' + escapeXml(value) + ']</li>');
    });

    out.w('</ul>');
  };
}
(module.exports = require("marko").c(__filename)).c(create);