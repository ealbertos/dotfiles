function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      attr = __helpers.a;

  return function render(data, out) {
    out.w('<div data-attr="Hello &lt;John&gt; &lt;hello&gt;"' + attr("data-nested-attr", out.captureString(function () {
      out.w('Hello &lt;John&gt; &lt;hello&gt;');
    }), false) + ' data-nested-attr2="Hello &lt;John&gt; &lt;hello&gt;">Hello &lt;John>\u00a9 &lt;hello> <START></div>');
  };
}
(module.exports = require("marko").c(__filename)).c(create);