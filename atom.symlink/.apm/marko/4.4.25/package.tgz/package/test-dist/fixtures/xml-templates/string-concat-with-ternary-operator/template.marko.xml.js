function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne;

  return function render(data, out) {
    out.w('\nA: ' + str(true ? 'ABC' : '') + '\nB: This should be outputted as well.\n');
  };
}
(module.exports = require("marko").c(__filename)).c(create);