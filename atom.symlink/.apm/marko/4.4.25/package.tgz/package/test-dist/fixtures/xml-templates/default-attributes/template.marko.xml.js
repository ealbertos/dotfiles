function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      __renderer = __helpers.r,
      bc_ = __renderer(require("../../taglib/default-attributes-tag")),
      __tag = __helpers.t;

  return function render(data, out) {
    __tag(out, bc_, {
      "prop1": "foo",
      "prop2": 50,
      "default1": "Default1",
      "default2": 100
    });
    __tag(out, bc_, {
      "prop1": "foo",
      "prop2": 50,
      "default1": "bar",
      "default2": 100
    });
  };
}
(module.exports = require("marko").c(__filename)).c(create);