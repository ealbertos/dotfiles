function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      __renderer = __helpers.r,
      bn_ = __renderer(require("../../taglib/simple-hello-tag")),
      __tag = __helpers.t;

  return function render(data, out) {
    __tag(out, bn_, data);
  };
}
(module.exports = require("marko").c(__filename)).c(create);