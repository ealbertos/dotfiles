function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      __renderer = __helpers.r,
      bm_ = __renderer(require("../../taglib/hello-renderer")),
      __tag = __helpers.t,
      escapeXmlAttr = __helpers.xa,
      escapeXml = __helpers.x,
      forEach = __helpers.f;

  return function render(data, out) {
    var rootClass = data.rootClass,
        colors = data.colors,
        message = data.message;

    __tag(out, bm_, {
      "name": "World"
    });

    out.w('<div class="hello-world ' + escapeXmlAttr(rootClass) + '">' + escapeXml(message) + '</div>');

    if (notEmpty(colors)) {
      out.w('<ul>');

      forEach(colors, function (color) {
        out.w('<li class="color">' + escapeXml(color) + '</li>');
      });

      out.w('</ul>');
    }

    if (empty(colors)) {
      out.w('<div>No colors!</div>');
    }
  };
}
(module.exports = require("marko").c(__filename)).c(create);