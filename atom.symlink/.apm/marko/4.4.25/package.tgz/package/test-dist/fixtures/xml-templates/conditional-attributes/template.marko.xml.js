function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      attr = __helpers.a;

  return function render(data, out) {
    out.w('<div' + attr("class", false ? "some-class" : '') + '></div><div' + attr("class", true ? "some-class" : '') + '></div><div' + attr("class", data.name) + '></div>');
  };
}
(module.exports = require("marko").c(__filename)).c(create);