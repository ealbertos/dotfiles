function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      escapeXml = __helpers.x,
      attr = __helpers.a;

  return function render(data, out) {
    function greeting(name) {
      return __helpers.c(out, function () {
        out.w('<p class="greeting">Hello, ' + escapeXml(name) + '!</p>');
      });
    }

    out.w(escapeXml(greeting("World")) + ', ' + escapeXml(greeting("Frank")));

    function section(url, title, body) {
      return __helpers.c(out, function () {
        out.w('<div class="section"><h1><a' + attr("href", url) + '>' + escapeXml(title) + '</a></h1><p>' + escapeXml(body) + '</p></div>');
      });
    }

    out.w(section("http://www.ebay.com/", "ebay", __helpers.c(out, function () {
      out.w('<i>Visit eBay</i>');
    })));
  };
}
(module.exports = require("marko").c(__filename)).c(create);