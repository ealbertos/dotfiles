function create(__helpers) {
  var str = __helpers.s,
      empty = __helpers.e,
      notEmpty = __helpers.ne,
      __renderer = __helpers.r,
      bg_ = __renderer(require("marko-layout/placeholder-tag")),
      __tag = __helpers.t;

  return function render(data, out) {
    if (data.showHeader !== false) {
      out.w('<h1>');
      __tag(out, bg_, {
        "name": "header",
        "content": data.layoutContent
      }, function (out) {
        out.w('DEFAULT TITLE');
      });

      out.w('</h1>');
    }

    out.w('<div>');
    __tag(out, bg_, {
      "name": "body",
      "content": data.layoutContent
    });

    out.w('</div>');
    __tag(out, bg_, {
      "name": "footer",
      "content": data.layoutContent
    });
    __tag(out, bg_, {
      "name": "empty",
      "content": data.layoutContent
    });
  };
}
(module.exports = require("marko").c(__filename)).c(create);